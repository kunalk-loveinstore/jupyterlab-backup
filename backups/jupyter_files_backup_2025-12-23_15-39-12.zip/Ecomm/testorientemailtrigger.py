import os
import urllib
import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime
import smtplib
from email.message import EmailMessage

# ─── SQL SERVER CONFIG ──────────────────────────────────────────────────────── #
SERVER         = "157.119.230.120,4071"
DATABASE       = "PDPSearchEcom_Tableau"
USER           = "ecomm"
PASSWORD       = "Hs%6uCx"
DRIVER         = "ODBC Driver 17 for SQL Server"
SCHEMA         = "dbo"
SOURCE_TABLE   = "OrientPDPDatav1"

# ─── EMAIL CONFIG ───────────────────────────────────────────────────────────── #
sender_email   = "analytics@loveinstore.com"
app_password   = "obob hnzt jzwn mnvu"
recipients     = [
    #"orientelectricecomm@loveinstore.com"
    "yogeshk@Loveinstore.com",
    # "ektas@loveinstore.com",
    # "ananyav@loveinstore.com",
    # "premg@accountmein.com"
]
subject_tpl    = "Daily Orient PDP Raw Report – Data for {date} at {time}"
body_template  = """
Hi,

Please find attached the Amazon PDP Raw data for {date} at {time}.

Regards,
Ecomm Team
"""

# ─── BUILD CONNECTION ENGINE ───────────────────────────────────────────────── #
odbc_str = (
    f"DRIVER={DRIVER};"
    f"SERVER={SERVER};"
    f"DATABASE={DATABASE};"
    f"UID={USER};"
    f"PWD={PASSWORD}"
)
conn_url = f"mssql+pyodbc:///?odbc_connect={urllib.parse.quote_plus(odbc_str)}"
engine   = create_engine(conn_url)

# ─── FETCH LATEST DATE ─────────────────────────────────────────────────────── #
with engine.connect() as conn:
    max_date_df = pd.read_sql_query(
        f"SELECT MAX(CAST([Date] AS DATE)) AS max_date FROM {SCHEMA}.{SOURCE_TABLE}",
        conn
    )
max_date = max_date_df["max_date"].iloc[0]

# ─── PULL ONLY LATEST DATE’S DATA ──────────────────────────────────────────── #
with engine.connect() as conn:
    df = pd.read_sql_query(
        f"SELECT * FROM {SCHEMA}.{SOURCE_TABLE} WHERE CAST([Date] AS DATE) = ?",
        conn,
        params=(max_date,)
    )

if df.empty:
    raise ValueError(f"No data found for latest date ({max_date}) in table {SCHEMA}.{SOURCE_TABLE}!")

# ─── WRITE TO EXCEL ───────────────────────────────────────────────────────── #
date_str  = max_date.strftime("%Y%m%d")
file_name = f"OrientPDP_Report_{date_str}.xlsx"
file_path = os.path.join(os.getcwd(), file_name)
df.to_excel(file_path, index=False)

# ─── GET & ROUND CURRENT TIME ──────────────────────────────────────────────── #
now      = datetime.now()
rounded  = now.replace(minute=0, second=0, microsecond=0)
time_str = rounded.strftime("%I:%M %p")
formatted_date = max_date.strftime("%d-%b-%Y")

# ─── CONSTRUCT & SEND EMAIL ───────────────────────────────────────────────── #
msg = EmailMessage()
msg["From"]    = sender_email
msg["To"]      = ", ".join(recipients)
msg["Subject"] = subject_tpl.format(date=formatted_date, time=time_str)
msg.set_content(body_template.format(date=formatted_date, time=time_str))

with open(file_path, "rb") as f:
    msg.add_attachment(
        f.read(),
        maintype="application",
        subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=file_name
    )

try:
    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)
    print("✅ Email sent successfully to:", ", ".join(recipients))

    # ─── CLEAN UP ───────────────────────────────────────────────────────────── #
    os.remove(file_path)
    print("✅ Deleted temporary file:", file_path)

except Exception as e:
    print("❌ Failed to send email:", e)
