# report_generator_app.py

import streamlit as st
import pandas as pd
from io import BytesIO

# Sample raw data
def get_sample_data():
    return pd.DataFrame({
        'Date': pd.date_range(start='2023-01-01', periods=10),
        'Region': ['North', 'South'] * 5,
        'Sales': [1000, 1200, 900, 1100, 1050, 980, 1120, 950, 1000, 1080]
    })

# Function to generate Excel report
def generate_excel_report(df_filtered):
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='xlsxwriter')
    df_filtered.to_excel(writer, index=False, sheet_name='Report')
    
    workbook = writer.book
    worksheet = writer.sheets['Report']
    format1 = workbook.add_format({'num_format': '#,##0'})
    worksheet.set_column('C:C', 12, format1)
    
    writer.close()
    output.seek(0)
    return output

# Streamlit UI
st.title("📊 Simple Report Generator")

# Step 1: Load data
data = get_sample_data()

# Step 2: UI filters
region_filter = st.selectbox("Select Region", options=data['Region'].unique())
start_date = st.date_input("Start Date", value=data['Date'].min())
end_date = st.date_input("End Date", value=data['Date'].max())

# Step 3: Filter data
filtered_data = data[
    (data['Region'] == region_filter) &
    (data['Date'] >= pd.to_datetime(start_date)) &
    (data['Date'] <= pd.to_datetime(end_date))
]

# Step 4: Show preview
st.subheader("📋 Preview")
st.dataframe(filtered_data)

# Step 5: Download Excel
excel_file = generate_excel_report(filtered_data)
st.download_button(
    label="📥 Download Excel Report",
    data=excel_file,
    file_name=f"{region_filter}_Sales_Report.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)
