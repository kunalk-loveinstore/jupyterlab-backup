import subprocess

ps_command = """
Get-ScheduledTask | 
Where-Object {
    ($_.Actions.Execute -like "*.py") -or ($_.Actions.Arguments -like "*.py")
} | 
Select-Object TaskName, 
              @{Name="Time";Expression={($_.Triggers | Select-Object -First 1).StartBoundary}},
              @{Name="Arguments";Expression={$_.Actions.Arguments}} | 
Format-Table -AutoSize | Out-String
"""

result = subprocess.run(["powershell", "-Command", ps_command], capture_output=True, text=True)

print(result.stdout)
#@{Name="Execute";Expression={$_.Actions.Execute}}