from datetime import datetime, timedelta
import smtplib
from email.message import EmailMessage
import os

sender_email   = "reports.mis@loveinstore.com"
app_password   = "ydfd ntvg qcfp xxbi"
recipients     = [
    "kunalk@loveinstore.com","rahuly@loveinstore.com"
]
subject_tpl    = "TestEmail{date}"
body_template  = """
Dear All,

Please find attached the MR Wise Daily Login-Logout Reports.
These reports provide a detailed Login and Logout times of store visits by MR & Supervisors capturing Time utilization insights for FOS and CFT activities

Report Link :https://docs.google.com/spreadsheets/d/1Xfd6VDgIWuOTym0ClmbCYXuDW7OtGeqMg37ukItoXdw/edit?gid=1040818418#gid=1040818418

This data will help you analyze field operations more effectively and monitor time spent at the store level.

Note: If there are any changes or clarifications required, please let me know.

Regards,
Team Love In Store
"""

now = datetime.now() - timedelta(days=1)

rounded = now.replace(minute=0, second=0, microsecond=0)
time_str = rounded.strftime("%I:%M %p")
formatted_date = now.strftime("%d-%b-%Y")

msg = EmailMessage()
msg["From"]    = sender_email
msg["To"]      = ", ".join(recipients)
msg["Subject"] = subject_tpl.format(date=formatted_date, time=time_str)
msg.set_content(body_template.format(date=formatted_date, time=time_str))

try:
    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)
    print("✅ Email sent successfully to:", ", ".join(recipients))

    #os.remove(file_path)
    #print("✅ Deleted temporary file:", file_path)

except Exception as e:
    print("❌ Failed to send email:", e)


print("done")
