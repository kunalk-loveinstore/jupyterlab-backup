from datetime import datetime
current_time = datetime.now()

# Print the current time
print("Current Time:", current_time)
print("helloworld")