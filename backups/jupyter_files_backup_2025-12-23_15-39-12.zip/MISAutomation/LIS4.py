import tkinter as tk
from tkinter import filedialog, messagebox
import csv
import time
import os
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ---------- GUI ----------
root = tk.Tk()
root.title("Auto Login from CSV")
root.geometry("520x350")

csv_file_path = None
chrome_driver_path = None


def browse_csv():
    global csv_file_path
    path = filedialog.askopenfilename(title="Select CSV (A2=username, B2=password)",
                                      filetypes=[("CSV Files", "*.csv")])
    if path:
        csv_file_path = path
        lbl_csv.config(text=os.path.basename(path), fg="black")


def browse_chromedriver():
    global chrome_driver_path
    path = filedialog.askopenfilename(title="Select ChromeDriver Executable",
                                      filetypes=[("Executable Files", "*.exe"), ("All Files", "*.*")])
    if path:
        chrome_driver_path = path
        lbl_driver.config(text=os.path.basename(path), fg="black")


def run_script():
    global csv_file_path, chrome_driver_path

    if not csv_file_path or not chrome_driver_path:
        messagebox.showerror("Missing Files", "Please select both the CSV file and ChromeDriver before running.")
        return

    # ---------- Read CSV credentials ----------
    try:
        with open(csv_file_path, newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            rows = [r for r in reader]
        username = rows[1][0].strip()
        password = rows[1][1].strip()
    except Exception as e:
        messagebox.showerror("CSV Error", f"Could not read username/password from CSV:\n{e}")
        return

    # ---------- Chrome Setup ----------
    chrome_options = Options()
    chrome_options.add_argument("--start-maximized")
    chrome_options.add_experimental_option("detach", True)
    chrome_options.add_argument("--ignore-certificate-errors")
    chrome_options.add_argument("--allow-insecure-localhost")
    chrome_options.add_argument("--ignore-ssl-errors=yes")

    try:
        service = Service(chrome_driver_path)
        driver = webdriver.Chrome(service=service, options=chrome_options)
        wait = WebDriverWait(driver, 25)
        actions = ActionChains(driver)

        driver.get("https://appv2.loveinstore.com/Home")
        time.sleep(2)

        # ---------- Login ----------
        username_field = wait.until(EC.presence_of_element_located((By.ID, "UserName")))
        password_field = wait.until(EC.presence_of_element_located((By.ID, "Password")))
        login_button = wait.until(EC.element_to_be_clickable((By.ID, "sign")))

        driver.execute_script("arguments[0].removeAttribute('readonly');", username_field)
        driver.execute_script("arguments[0].removeAttribute('readonly');", password_field)

        username_field.clear()
        username_field.send_keys(username)
        password_field.clear()
        password_field.send_keys(password)
        login_button.click()

        # ---------- Wait for Sidebar ----------
        time.sleep(4)

        # ---------- Hover on Data Management ----------
        data_management = wait.until(EC.presence_of_element_located(
            (By.XPATH, "//a[contains(@href,'/Admin/DataManagement/Index') and .//span[contains(text(),'Data Management')]]")
        ))
        actions.move_to_element(data_management).perform()
        time.sleep(0.8)
        driver.execute_script("arguments[0].click();", data_management)
        time.sleep(1.5)

        # ---------- Click Attendance ----------
        attendance_link = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//a[contains(.,'Attendance') and not(contains(@href,'MonthlyAttendance'))]")
        ))
        actions.move_to_element(attendance_link).click().perform()
        time.sleep(1.5)

        # ---------- Click Monthly Attendance ----------
        monthly_attendance = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//a[contains(@href,'/AttendanceV2/MonthlyAttendanceV2') and contains(.,'Monthly Attendance')]")
        ))
        driver.execute_script("arguments[0].scrollIntoView(true);", monthly_attendance)
        actions.move_to_element(monthly_attendance).click().perform()

        # ---------- Wait for Monthly Attendance Page ----------
        wait.until(EC.presence_of_element_located((By.ID, "Sdatewise")))
        time.sleep(2)

        # ---------- Select Datewise ----------
        try:
            select_box = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[@id='select2-Sdatewise-container']")))
            driver.execute_script("arguments[0].scrollIntoView(true);", select_box)
            select_box.click()
            datewise_option = wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//li[contains(@id,'select2-Sdatewise-result') and normalize-space(text())='Datewise']")
            ))
            datewise_option.click()
        except Exception as e:
            print("Select2 Datewise selection issue:", e)

        # ---------- Fill Dates ----------
        first_day = datetime.today().replace(day=1).strftime("%d/%m/%Y")
        yesterday = (datetime.today() - timedelta(days=1)).strftime("%d/%m/%Y")

        try:
            from_input = wait.until(EC.presence_of_element_located((By.ID, "Sdate")))
        except:
            from_input = wait.until(EC.presence_of_element_located((By.NAME, "DateFrom")))

        driver.execute_script("arguments[0].removeAttribute('readonly');", from_input)
        from_input.clear()
        from_input.click()
        from_input.send_keys(first_day)
        actions.move_by_offset(0, 100).click().perform()

        try:
            to_input = wait.until(EC.presence_of_element_located((By.ID, "dateto")))
        except:
            to_input = wait.until(EC.presence_of_element_located((By.NAME, "DateTo")))

        driver.execute_script("arguments[0].removeAttribute('readonly');", to_input)
        to_input.clear()
        to_input.click()
        to_input.send_keys(yesterday)
        actions.move_by_offset(0, 100).click().perform()

        time.sleep(1)

        # ---------- Click Download Now (Dropdown Toggle) ----------
        download_dropdown = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//a[contains(@class,'dropdown-toggle') and contains(text(),'Download Now')]")
        ))
        driver.execute_script("arguments[0].scrollIntoView(true);", download_dropdown)
        driver.execute_script("arguments[0].click();", download_dropdown)
        time.sleep(1)

        # ---------- Click Master Export ----------
        master_export_btn = wait.until(EC.element_to_be_clickable((
            By.XPATH,
            "//button[@type='submit' and contains(@class,'dropdown-item') and @value='Export' and contains(.,'Master Export')]"
        )))
        driver.execute_script("arguments[0].scrollIntoView(true);", master_export_btn)
        driver.execute_script("arguments[0].click();", master_export_btn)

        messagebox.showinfo("Done", "✅ Automation completed: Login, Date selection, Download Now → Master Export executed successfully!")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to perform automation:\n{e}")


# ---------- GUI Layout ----------
tk.Label(root, text="Step 1: Select Credentials CSV (A2=username, B2=password)").pack(pady=5)
tk.Button(root, text="Browse CSV", command=browse_csv).pack()
lbl_csv = tk.Label(root, text="No file selected", fg="gray")
lbl_csv.pack()

tk.Label(root, text="Step 2: Select ChromeDriver Executable").pack(pady=10)
tk.Button(root, text="Browse ChromeDriver", command=browse_chromedriver).pack()
lbl_driver = tk.Label(root, text="No file selected", fg="gray")
lbl_driver.pack()

tk.Button(root, text="Run Auto Login", command=run_script,
          bg="green", fg="white", font=("Arial", 12, "bold")).pack(pady=25)

root.mainloop()
