import time
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from email.message import EmailMessage
from email.utils import make_msgid
import smtplib
from datetime import date,datetime

# ================= Configuration ====================

EMAIL_ADDRESS = 'reports.mis@loveinstore.com'
EMAIL_PASSWORD = 'ydfd ntvg qcfp xxbi'
TO_EMAIL = 'Afrizal@reckitt.com,afnaniza.maulizahma@reckitt.com,Vela.Lydia@reckitt.com,muhammadlazuardi.putra@reckitt.com,Lina.Wahyuningsih@reckitt.com, hannan.bahalwan@reckitt.com,Vikas.Golechha@reckitt.com,imelda.marten@reckitt.com'
CC_EMAIL = 'adityag@loveinstore.com,ketavs@loveinstore.com,⁠asthag@loveinstore.com,kunalk@loveinstore.com,puneetk@loveinstore.com,riteshk@loveinstore.com,harishb@loveinstore.com,ananyav@loveinstore.com,aryop@loveinstore.com,⁠harishb@loveinstore.com'

# CSV_PATH = r'D:\Tracker Script\Merged Files\Cipla_DSR_Enrollment.xlsx'
IMAGE_PATH = r'C:\Users\Administrator\LIS\MISAutomation\MJN\dashboard.png'
DASHBOARD_URL = 'https://app.powerbi.com/view?r=eyJrIjoiOTcwN2ExMjEtY2ZkZS00MTdjLThmNmUtOGFiZGViMDZhMTNlIiwidCI6ImI5OGUzMGNiLWU4MWYtNGY0MS04ZmM3LWU5NGNiZWQyYjRhZCJ9&pageName=387cd312897770c30279'  # Your report link

# =============== Step 1: Take Screenshot =============
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")

driver = webdriver.Chrome(options=chrome_options)
driver.get(DASHBOARD_URL)

time.sleep(30)  # Wait for page to load fully (adjust as needed)

driver.save_screenshot(IMAGE_PATH)
driver.quit()
today = date.today().strftime("%d-%b-%Y")  
today2 = datetime.now().strftime("%d-%b-%Y %H:%M:%S")

# =============== Step 2: Send Email ===================
msg = EmailMessage()
msg['Subject'] = f'MJN Power BI Dashboard {today}'
msg['From'] = EMAIL_ADDRESS
msg['To'] = TO_EMAIL
msg['Cc'] = CC_EMAIL

image_cid = make_msgid(domain='xyz.com')[1:-1]

msg.set_content("HTML email with dashboard")

msg.add_alternative(f"""
<html>
  <body>
    <p>Dear Mead Johnson Team,</p>
    <p>Please find below the link to your daily performance dashboard</p>
    <p><a href="https://app.powerbi.com/view?r=eyJrIjoiOTcwN2ExMjEtY2ZkZS00MTdjLThmNmUtOGFiZGViMDZhMTNlIiwidCI6ImI5OGUzMGNiLWU4MWYtNGY0MS04ZmM3LWU5NGNiZWQyYjRhZCJ9&pageName=610f0e352380a28c47ac" target="_blank">Click here to view the dashboard</a></p>
    <img src="cid:{image_cid}" width="900">
    <p>ScreenShot Time - {today2} IST</p>
    <p> As of now, we are still in the process of updating the master data. Additionally, the BI portal is being built as per the sample shared by Mead Johnson Team. Please note that it is being refined continuously </p>
    <p>Feel free to reach out for any inputs or adjustments you'd like us to incorporate.</p>
    <p>Regards,<br>Loveinstore Team</p>
  </body>
</html>
""", subtype='html')

# Attach Screenshot
with open(IMAGE_PATH, 'rb') as img:
    msg.get_payload()[1].add_related(img.read(), maintype='image', subtype='png', cid=f"<{image_cid}>")



# Send Email
try:
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        smtp.send_message(msg)
    print("✅ Email sent with dashboard screenshot & CSV!")
except Exception as e:
    print("❌ Failed to send email:", e)

