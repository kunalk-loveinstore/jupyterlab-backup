import pandas as pd
import pyodbc
import os
import gspread
from gspread_dataframe import get_as_dataframe
from oauth2client.service_account import ServiceAccountCredentials
from gspread_dataframe import set_with_dataframe

from datetime import datetime
import numpy as np


print("Script Run Started")

scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(r"C:/Users/Administrator/LIS/Dabur/python-459011-73acbdff4227.json", scope)
client = gspread.authorize(creds)

# Open Sheet
sheet = client.open_by_key("12cpGc8fPEt1cMnt7A_kxAPspsTfWQyFV24metXDnOts") # Master Sheets ( Dimensions Sheet)
Data = sheet.worksheet("Data")
UserSheet = sheet.worksheet("User")

server = '157.119.230.120,4071'    
database = 'PowerBI_LISV2'      
username = 'sa'
password = 'Y0m@Sql.!.123'

# Connection string
conn_str = f"""
    DRIVER={{ODBC Driver 17 for SQL Server}};
    SERVER={server};
    DATABASE={database};
    UID={username};
    PWD={password};
    TrustServerCertificate=yes;
"""

query = """ 
WITH CTE AS 
(SELECT 
(TXT.UserName+'-'+ TXT.VISIT_DATE)AS UserVisitKey ,
TXT.Visit_Date,
TXT.UserName,
(TXT.VISIT_DATE +' '+TXT.CHEKINTIME) AS ChekinTime,
TXT.LISStoreCode,
(TXT.VISIT_DATE+'-'+TXT.LISStoreCode+'-'+TXT.UserName) AS StoreDateKey,
TXT.StoreName,TXT.Designation,
(TXT.VISIT_DATE +' '+TXT.CHECKOUTTIME ) AS Chekouttime,
TXT.FullName,
NoPermissionReason
FROM
(SELECT   FORMAT(CONVERT(DATETIME, SA.[VisitDate], 105), 'dd-MM-yyyy') AS Visit_Date,
SA.LISStoreCode,SA.StoreName, SA.UserName,SA.Designation,SA.FullName,
CONVERT(varchar, CAST([CheckIn-Time] AS TIME), 8) AS CHEKINTIME,
CONVERT(varchar, CAST([CheckOut-Time] AS TIME), 8) AS CHECKOUTTIME,
NoPermissionReason
FROM [PowerBI_LISV2].[BrillonMTManagement].[ISPStoreAttendance_NormalExport] AS SA
LEFT JOIN [PowerBI_LISV2].[BrillonMTManagement].UserMaster AS UM ON UM.UserName = SA.UserName
WHERE  [Month] = MONTH(GETDATE()-1) AND [Year] = YEAR(GETDATE()-1)
AND UM.Status =  'True' and  SA.UserName not like '%Star%' and SA.UserName not like '%TEST%'
)AS TXT
)
SELECT * FROM CTE;
"""

UserDataQuery ="""
SELECT 
DISTINCT
UM.EmployeeID,UM.UserName, 
UM.FullName,
UM.Region, UM.State,UM.City,UM.Status, UH.Supervisor,UM2.FullName as SupervisorName
from [PowerBI_LISV2].[BrillonMTManagement].UserMaster AS UM 
LEFT JOIN [PowerBI_LISV2].[BrillonMTManagement].UserHierarchyListReport AS UH ON UH.ISP = UM.UserName
LEFT JOIN [PowerBI_LISV2].[BrillonMTManagement].UserMaster AS UM2 ON UH.Supervisor = UM2.UserName
WHERE UM.Status = 'True'
and  UM.UserName not like '%Star%' and  UM.UserName not like '%Test%' and  UM.UserName not like '%TEST%';

""" 
conn = pyodbc.connect(conn_str)
df = pd.read_sql(query, conn)
UserData = pd.read_sql(UserDataQuery, conn)

UserData2=UserData.drop(columns = ['FullName'])

print("data extracted....")
loginlogout = pd.merge(df,UserData2, how = 'left',on = 'UserName')
loginlogout['ChekinRank'] = loginlogout.groupby(['StoreDateKey'])['ChekinTime'].rank(method='dense', ascending=True).astype(int)
loginlogout2= loginlogout[loginlogout['ChekinRank']==1]

loginlogout2=loginlogout2.drop(columns = ['ChekinRank'])

loginlogout2 = loginlogout2.drop_duplicates()
loginlogout2.at[0, 'LastUpdated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

print("csv updated....")
loginlogout2.to_csv(r'C:\Users\Administrator\LIS\Dabur\daburloginlogout.csv', index=False)

loginlogout2 = loginlogout2.drop_duplicates()
#Sending df on sheet
Data.batch_clear(["A1"])
set_with_dataframe(Data, loginlogout2)

UserSheet.batch_clear(["A1"])
set_with_dataframe(UserSheet, UserData)

print("Google Sheets are updated")

# emailer

from datetime import datetime, timedelta
import smtplib
from email.message import EmailMessage

sender_email   = "reports.brillon@loveinstore.com"
app_password   = "wljo ihuw slkk pdic"
# recipients     = ["tomarsatender92@gmail.com","santoshkam646@gmail.com","easakhan2021@gmail.com","Sushma662@gmail.com","mukulsharma4123@gmail.com","mukulsharma4123@gmail.com","mrinalnaskar98@gmail.com","Venkateshvs1317@gmail.com","Venkateshvs1317@gmail.com","jayaram910@gmail.com","Kiranmadival001@gmail.com","amin.shaikh9999@gmail.com","harishb@loveinstore.com","balk@loveinstore.com",
# "praveen.p@loveinstore.com",
#     "karunat@loveinstore.com","kunalk@loveinstore.com","reports.mis@loveinstore.com"
# ]


subject_tpl    = "Brillon_ MR Wise Daily Login & Logout Reports updated till {date}"
body_template  = """
Dear All,

Please find attached the MR Wise Daily Login-Logout Reports.
These reports provide a detailed Login and Logout times of store visits by MR & Supervisors capturing Time utilization insights for FOS and CFT activities

Report Link :
https://docs.google.com/spreadsheets/d/12cpGc8fPEt1cMnt7A_kxAPspsTfWQyFV24metXDnOts/edit?gid=1040818418#gid=1040818418

This data will help you analyze field operations more effectively and monitor time spent at the store level.

Note: If there are any changes or clarifications required, please let me know. if you are unable to access it from your email id , please raise the access request from google sheet.

Regards,
Team Love In Store
"""

now = datetime.now() - timedelta(days=1)

rounded = now.replace(minute=0, second=0, microsecond=0)
time_str = rounded.strftime("%I:%M %p")
formatted_date = now.strftime("%d-%b-%Y")

msg = EmailMessage()
msg["From"]    = sender_email
msg["To"]      = ", ".join(recipients)
msg["Subject"] = subject_tpl.format(date=formatted_date, time=time_str)
msg.set_content(body_template.format(date=formatted_date, time=time_str))

try:
    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)
    print("✅ Email sent successfully to:", ", ".join(recipients))

    os.remove(file_path)
    print("✅ Deleted temporary file:", file_path)

except Exception as e:
    print("❌ Failed to send email:", e)


print("done")

















