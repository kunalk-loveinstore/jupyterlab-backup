# AutomateOrientPDP.py
"""
ETL Script: Incrementally load, clean, transform, and join
 data into the OrientPDPData table in SQL Server, with
 ping‑style step logging, sequence enforcement, and robust
 error handling for Windows 11.
"""
import os
import re
import sys
import urllib

import numpy as np
import pandas as pd
from sqlalchemy import create_engine, inspect

TOTAL_STEPS = 9

def ping(step, description):
    print(f"\nPING ETL > Step {step}/{TOTAL_STEPS}: {description}...", end=" ")

def fail(e):
    print(f"\nFAIL ({e})")
    sys.exit(1)

def extract_num(val):
    if pd.isna(val):
        return np.nan
    s = str(val).replace(",", "")
    m = re.search(r"(-?\d+(?:\.\d+)?)", s)
    return float(m.group(1)) if m else np.nan

def trim_proper(s):
    return s.strip().title() if isinstance(s, str) else s

def parse_delivery_date(cell):
    if pd.isna(cell):
        return pd.NaT
    try:
        return pd.to_datetime(cell, dayfirst=True, errors="coerce")
    except:
        return pd.NaT

def clean_delivery_date_raw(x):
    if pd.isna(x):
        return x
    s = str(x)
    s = re.sub(r"\bDays\b", "", s, flags=re.IGNORECASE)
    s = re.sub(r"^(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),?\s*", "", s, flags=re.IGNORECASE)
    # range: pick max day
    m = re.match(r"(\d{1,2})\s*-\s*(\d{1,2})\s*([A-Za-z]+)", s)
    if m:
        _, day2, mon = m.groups()
        return f"{day2}-{mon} {pd.Timestamp.today().year}"
    # single date
    m2 = re.search(r"(\d{1,2})\s*([A-Za-z]+)", s)
    if m2:
        day, mon = m2.group(1), m2.group(2)
        return f"{day}-{mon} {pd.Timestamp.today().year}"
    s = re.sub(r"\.", "", s)
    return s.strip()

def main():
    # 1) CONNECT & VERIFY SOURCE TABLE
    ping(1, 'Connect to SQL Server & verify source table')
    try:
        conn_str = (
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=157.119.230.120,4071;'
            'DATABASE=PDPSearchEcom_Tableau;'
            'UID=ecomm;PWD=Hs%6uCx;'
        )
        engine = create_engine(f"mssql+pyodbc:///?odbc_connect={urllib.parse.quote_plus(conn_str)}")
        insp = inspect(engine)
        if not insp.has_table('AmazonPDPSearchTableauOrientElectric', schema='PDPSearchManagement'):
            raise RuntimeError('Source table not found')
        print('OK')
    except Exception as e:
        fail(e)

    # 2) DETERMINE INCREMENTAL BOUNDARY
    ping(2, 'Check/prepare incremental logic')
    try:
        tgt_s, tgt_t = 'dbo','OrientPDPData'
        if insp.has_table(tgt_t, schema=tgt_s):
            q = f"SELECT MAX(AmazonPDPSearchId) AS mx FROM {tgt_s}.{tgt_t}"
            max_id = pd.read_sql(q, engine).iloc[0]['mx'] or 0
        else:
            max_id = 0
        print(f'OK (max_id={max_id})')
    except Exception as e:
        fail(e)

    # 3) VERIFY EXCEL
    ping(3, 'Validate Excel file & sheets')
    try:
        base = r'C:\Users\Administrator\LIS\Ecomm'
        path = os.path.join(base, 'OrientElectric_ProductData.xlsx')
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        xls = pd.ExcelFile(path)
        needed = {'ProductData','PincodeData','SellerData'}
        missing = needed - set(xls.sheet_names)
        if missing:
            raise RuntimeError(f'Missing sheets: {missing}')
        print('OK')
    except Exception as e:
        fail(e)

    # 4) INCREMENTAL BOUNDARY
    ping(4, 'Determine incremental boundary')
    print(f'OK (using ID > {max_id})')

    # 5) EXTRACT SOURCE
    ping(5, 'Fetch new rows (required columns)')
    try:
        sql = f"""
            SELECT AmazonPDPSearchId,[Date],[Times Of Day],Times,Platform,Pincode,
                   ProductCode,SalesPrice,MRP,Availability,Category,ProductRank,
                   SellerName1,DeliveryType1,DeliveryDate1,TotalRating,AverageRating
            FROM PDPSearchManagement.AmazonPDPSearchTableauOrientElectric
            WHERE AmazonPDPSearchId > {max_id}
              AND LTRIM(RTRIM(Category)) <> 'Home & Kitchen'
        """
        df = pd.read_sql(sql, engine)
        if df.empty:
            print('No new rows. Exiting.')
            sys.exit(0)
        df.columns = df.columns.str.strip()
        print(f'OK ({len(df)} rows fetched)')
    except Exception as e:
        fail(e)

    # 6) CLEAN & TRANSFORM FACT DATA
    ping(6, 'Clean & transform fact data')
    try:
        df['OrderDate'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
        df['Date'] = df['OrderDate'].dt.strftime('%d-%m-%Y')
        df['Times Of Day'] = pd.to_datetime(df['Times Of Day'], format='%I:%M %p', errors='coerce').dt.strftime('%I:%M %p')

        # normalize text fields
        for c in ['Times','Platform','ProductCode','Availability','Category','SellerName1']:
            df[c] = df[c].apply(trim_proper)

        # numeric casts
        df['Pincode'] = pd.to_numeric(df['Pincode'], errors='coerce')
        df['TotalRating'] = pd.to_numeric(df['TotalRating'], errors='coerce')
        df['AverageRating'] = df['AverageRating'].apply(extract_num).round(1)

        # clean raw delivery columns
        df['DeliveryType1'] = df['DeliveryType1'].astype(str).replace(r'[A-Za-z]+','',regex=True)
        df['DeliveryDate1'] = df['DeliveryDate1'].apply(clean_delivery_date_raw)

        # parse & calc TTD
        df['Delivery Type'] = df['DeliveryType1'].apply(extract_num)
        df['Delivery Date'] = df['DeliveryDate1'].apply(parse_delivery_date)
        df['TTD'] = (df['Delivery Date'] - df['OrderDate']).dt.days
        df['Delivery Status'] = np.where(df['TTD'] <= 3, 'On Time', 'Delay')

        # extract year/month fallback
        df['Delivery Year'] = df['Delivery Date'].dt.year.fillna(df['OrderDate'].dt.year)
        df['Delivery Month'] = df['Delivery Date'].dt.month.fillna(df['OrderDate'].dt.month)

        # price & discount
        df['MRP_raw'] = df['MRP'].apply(extract_num)
        df['SalesPrice_raw'] = df['SalesPrice'].apply(extract_num)
        df['SalesPrice'] = df.apply(
            lambda r: (
                np.nan if pd.isna(r.MRP_raw) and pd.isna(r.SalesPrice_raw)
                else (r.MRP_raw if pd.isna(r.SalesPrice_raw)
                      else (r.SalesPrice_raw if pd.isna(r.MRP_raw)
                            else min(r.MRP_raw, r.SalesPrice_raw)))
            ), axis=1
        ).round(0)
        df['MRP'] = df.apply(
            lambda r: (
                np.nan if pd.isna(r.MRP_raw) and pd.isna(r.SalesPrice_raw)
                else (r.SalesPrice_raw if pd.isna(r.MRP_raw)
                      else (r.MRP_raw if pd.isna(r.SalesPrice_raw)
                            else max(r.MRP_raw, r.SalesPrice_raw)))
            ), axis=1
        ).round(0)
        df['Discount Value'] = (df['MRP'] - df['SalesPrice']).round(0)
        df['Discount %'] = ((df['Discount Value'] / df['MRP']) * 100).round(0)

        # cleanup
        df.drop(columns=['MRP_raw','SalesPrice_raw','OrderDate'], inplace=True)
        print('OK')
    except Exception as e:
        fail(e)

    # 7a) INNER JOIN ProductData
    ping(7, 'Inner join → ProductData')
    try:
        prod = pd.read_excel(path, sheet_name='ProductData')
        prod.columns = prod.columns.str.strip()
        prod['Product Code'] = prod['Product Code'].apply(trim_proper)
        df['ProductCode'] = df['ProductCode'].apply(trim_proper)
        prod.drop(columns=['Platform'], errors='ignore', inplace=True)
        before = len(df)
        df = df.merge(prod, left_on='ProductCode', right_on='Product Code', how='inner')
        after = len(df)
        print(f'OK ({before} → {after} rows)')
    except Exception as e:
        fail(e)

    # 7b) INNER JOIN PincodeData
    ping(7, 'Inner join → PincodeData')
    try:
        pin = pd.read_excel(path, sheet_name='PincodeData')
        pin = pin[['Pincode','City']]
        pin.columns = pin.columns.str.strip()
        pin['Pincode'] = pd.to_numeric(pin['Pincode'], errors='coerce')
        df['Pincode'] = pd.to_numeric(df['Pincode'], errors='coerce')
        before = len(df)
        df = df.merge(pin, on='Pincode', how='inner')
        after = len(df)
        print(f'OK ({before} → {after} rows)')
    except Exception as e:
        fail(e)

    # 7c) LEFT JOIN SellerData
    ping(7, 'Left join → SellerData')
    try:
        sd = pd.read_excel(path, sheet_name='SellerData')
        sd.columns = sd.columns.str.strip()
        nc = next(c for c in sd.columns if c.replace(' ','').lower()=='sellername')
        ac = next(c for c in sd.columns if c.replace(' ','').lower() in('isauthorised','sellertype'))
        sd = sd[[nc,ac]].rename(columns={nc:'Seller Name',ac:'IsAuthorised'})
        sd['Seller Name'] = sd['Seller Name'].apply(trim_proper)
        df['SellerName1'] = df['SellerName1'].apply(trim_proper)
        df.rename(columns={'SellerName1':'Seller Name'}, inplace=True)
        before = len(df)
        df = df.merge(sd, on='Seller Name', how='left', indicator=True)
        df['Seller Type'] = df.apply(
            lambda r: None if pd.isna(r['Seller Name']) else ('Authorized' if r['_merge']=='both' else 'UnAuthorized'),
            axis=1
        )
        df.drop(columns=['_merge','IsAuthorised'], inplace=True)
        after = len(df)
        print(f'OK ({before} → {after} rows)')
    except Exception as e:
        fail(e)

    # 8) SORT, DROP & REORDER
    ping(8, 'Drop raw ➔ Rename, sort & reorder columns')
    try:
        # drop unused raw columns
        df.drop(columns=['DeliveryType1','DeliveryDate1'], inplace=True)
        # rename columns
        df.rename(columns={
            'ProductRank':'Category Rank',
            'TotalRating':'Total Rating',
            'AverageRating':'Average Rating'
        }, inplace=True)
        # sort: Product Type DESC, others ASC
        df.sort_values(
            by=['Date','Times Of Day','City','Pincode','Product Type','Product Category','Product Name','AmazonPDPSearchId'],
            ascending=[True,True,True,True,False,True,True,True], inplace=True
        )
        # final column order
        cols = [
            'AmazonPDPSearchId','Platform','Date','Times Of Day','Times','Pincode',
            'City','Product Code','Product Name','Model Name','Brand Name',
            'Product Type','Product Category','Pack Size',
            'SalesPrice','MRP','Discount Value','Discount %','Availability','Category',
            'Category Rank','Seller Name','Seller Type',
            'Delivery Date','TTD','Delivery Status',
            'Competition Code','MOP'
        ]
        df = df[cols]
        print('OK')
    except Exception as e:
        fail(e)

    # 9) WRITE TO TARGET
    ping(9, 'Write to OrientPDPData')
    try:
        if max_id == 0:
            df.to_sql('OrientPDPData', engine, schema=tgt_s, if_exists='replace', index=False)
            print(f'OK (created {len(df)} rows)')
        else:
            df.to_sql('OrientPDPData', engine, schema=tgt_s, if_exists='append', index=False)
            print(f'OK (appended {len(df)} rows)')
    except Exception as e:
        fail(e)

if __name__ == '__main__':
    main()
    print("\nETL completed successfully.\nEND")
    sys.exit(0)