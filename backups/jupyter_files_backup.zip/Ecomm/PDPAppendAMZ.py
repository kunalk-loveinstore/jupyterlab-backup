import logging
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.types import DATE, BigInteger
from urllib.parse import quote_plus
import numpy as np

# ─── CONFIGURATION ─────────────────────────────────────────────────────────
SERVER     = "157.119.230.120,4071"
DATABASE   = "PDPSearchEcom_Tableau"
USER       = "ecomm"
PASSWORD   = "Hs%6uCx"
DRIVER     = "ODBC Driver 17 for SQL Server"
SCHEMA     = "dbo"
SRC_TABLES = [
    ("Orient_PDP_Amazonv2", "Amazon"),
    ("Orient_PDP_Flipkartv2", "Flipkart"),
]
TGT_TABLE  = "OrientPDPDatav1"

# ─── LOGGING SETUP ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)5s | %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger()

# ─── M CODE TRANSFORMATION ──────────────────────────────────────────────────

def apply_full_m_transform(df):
    # 1. Ensure numeric and correct types
    for col in ["MRP", "Sales Price"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if "Discount %" in df.columns:
        df["Discount %"] = pd.to_numeric(df["Discount %"], errors="coerce") / 100
    if "Times Of Day" in df.columns:
        df["Times Of Day"] = pd.to_datetime(df["Times Of Day"], errors='coerce').dt.time

    # 2. Sort by Platform and PDPSearchId (ascending)
    if "Platform" in df.columns and "PDPSearchId" in df.columns:
        df = df.sort_values(by=["Platform", "PDPSearchId"], ascending=[True, True])

    # 3. Remove column 'Discount Value' if exists
    if "Discount Value" in df.columns:
        df = df.drop(columns=["Discount Value"])

    # 4. Add MRPa column (per M logic)
    def calc_mrpa(row):
        mrp = row.get("MRP")
        sp = row.get("Sales Price")
        if pd.isna(mrp) and pd.isna(sp):
            return np.nan
        if pd.isna(sp):
            return mrp
        if pd.isna(mrp):
            return sp
        return mrp if mrp >= sp else sp

    df["MRPa"] = df.apply(calc_mrpa, axis=1)

    # 5. Add Sales Pricea column
    def calc_salespricea(row):
        mrp = row.get("MRP")
        sp = row.get("Sales Price")
        if pd.isna(mrp) and pd.isna(sp):
            return np.nan
        if pd.isna(sp):
            return mrp
        if pd.isna(mrp):
            return sp
        return mrp if mrp <= sp else sp

    df["Sales Pricea"] = df.apply(calc_salespricea, axis=1)

    # 6. Remove original MRP, Sales Price, Discount % columns
    for c in ["MRP", "Sales Price", "Discount %"]:
        if c in df.columns:
            df = df.drop(columns=[c])

    # 7. Rename new columns
    df.rename(columns={"MRPa": "MRP", "Sales Pricea": "Sales Price"}, inplace=True)

    # 8. Add Discount Value
    df["Discount Value"] = df["MRP"] - df["Sales Price"]

    # 9. Add Discount %
    df["Discount %"] = df.apply(
        lambda row: row["Discount Value"] / row["MRP"] if pd.notna(row["MRP"]) and row["MRP"] != 0 else np.nan,
        axis=1
    )

    # 10. Enforce numeric types again (to match Changed Type1)
    for c in ["MRP", "Sales Price", "Discount Value"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if "Discount %" in df.columns:
        df["Discount %"] = pd.to_numeric(df["Discount %"], errors="coerce")

    # 11. Reorder columns (optional, as per your M code order)
    final_order = [
        "PDPSearchId", "Platform", "Date", "Times Of Day", "Times", "Pincode", "City", "Product Code", "Product Name",
        "Brand Name", "Product Type", "Model Name", "Business Unit", "Product Categories", "Sub Categories",
        "MRP", "Sales Price", "Discount Value", "Discount %", "Pack Size", "Availability", "Category", "Category Rank",
        "Total Rating", "Average Rating", "Shipment Detail", "No Of Seller", "Seller Type", "Seller_1_Name",
        "SalesPrice1", "Availability1", "DeliveryType1", "DeliveryDate1", "Seller_2_Name", "SalesPrice2", "Availability2",
        "DeliveryType2", "DeliveryDate2", "Seller_3_Name", "SalesPrice3", "Availability3", "DeliveryType3", "DeliveryDate3",
        "Seller_4_Name", "SalesPrice4", "Availability4", "DeliveryType4", "DeliveryDate4", "Seller_5_Name", "SalesPrice5",
        "Availability5", "DeliveryType5", "DeliveryDate5", "Pincode Contribution", "Promo_Status", "Promo MOP", "Units",
        "List SKU per Model Name", "Per SKU Unit Contribution", "Projection Per Day", "Projection Per Crawl",
        "PerCrawlPincodeUnit", "Revised MOP", "Least MOP", "Max MOP", "Competition Code"
    ]
    df = df[[c for c in final_order if c in df.columns]]

    # 12. Remove '(' and ')' from Total Rating
    if "Total Rating" in df.columns:
        df["Total Rating"] = df["Total Rating"].astype(str).str.replace("(", "", regex=False).str.replace(")", "", regex=False)

    # 13. Add New MOP Flag column
    def mop_flag(row):
        least_mop = row.get("Least MOP")
        max_mop = row.get("Max MOP")
        sales_price = row.get("Sales Price")
        if pd.isna(least_mop) and pd.isna(max_mop):
            return np.nan
        if pd.isna(sales_price):
            return np.nan
        if pd.notna(least_mop) and pd.notna(sales_price) and least_mop > sales_price:
            return "Low"
        if pd.notna(max_mop) and pd.notna(sales_price) and max_mop < sales_price:
            return "High"
        return "With In Range"

    df["New MOP Flag"] = df.apply(mop_flag, axis=1)

    # 14. Ensure Platform column is in Proper Case ("Amazon", "Flipkart")
    if "Platform" in df.columns:
        df["Platform"] = df["Platform"].str.capitalize()

    return df

# ─── GET TABLE COLUMNS ──────────────────────────────────────────────────────

def get_table_columns(insp, table_name, schema):
    if insp.has_table(table_name, schema=schema):
        return [c["name"] for c in insp.get_columns(table_name, schema=schema)]
    return []

def schema_matches(source_cols, target_cols):
    return source_cols == target_cols

# ─── MAIN ETL FUNCTION ───────────────────────────────────────────────────────

def run_etl():
    print("[PING] 1️⃣ Connecting to database")
    pw_esc = quote_plus(PASSWORD)
    url = f"mssql+pyodbc://{USER}:{pw_esc}@{SERVER}/{DATABASE}?driver={DRIVER.replace(' ', '+')}"
    engine = create_engine(url)
    insp = inspect(engine)
    log.info("Connected to database")

    # Read and combine source tables
    print("[PING] 2️⃣ Reading and combining Amazon & Flipkart source tables")
    combined_dfs = []
    for src_table, platform_name in SRC_TABLES:
        print(f"  [PING] Reading {src_table} (Platform: {platform_name})")
        df = pd.read_sql_table(src_table, engine, schema=SCHEMA)
        df["Platform"] = platform_name  # Set Platform column for every row
        combined_dfs.append(df)
    combined_df = pd.concat(combined_dfs, ignore_index=True)

    print("[PING] 3️⃣ Applying M-code style transformations")
    transformed_df = apply_full_m_transform(combined_df)
    final_cols = list(transformed_df.columns)

    tgt_exists = insp.has_table(TGT_TABLE, schema=SCHEMA)
    tgt_cols = get_table_columns(insp, TGT_TABLE, SCHEMA) if tgt_exists else []

    if tgt_exists and schema_matches(final_cols, tgt_cols):
        print("[PING] Target table schema matches - will append incrementally")
        create_new = False
    else:
        if tgt_exists:
            print("[PING] Target table schema mismatch - dropping and recreating")
            with engine.begin() as conn:
                conn.execute(text(f"DROP TABLE {SCHEMA}.{TGT_TABLE}"))
        else:
            print("[PING] Target table does not exist - will create new")
        create_new = True

    dtype_map = {
        "PDPSearchId": BigInteger(),
        "Date": DATE(),
        # Other columns inferred automatically
    }

    total_rows_appended = 0
    first_write_done = False

    chunk_size = 25   # SAFELY BELOW SQL PARAMETER LIMIT!

    # For each platform, filter and append only new records (incremental)
    for _, platform_name in SRC_TABLES:
        platform_proper = platform_name.capitalize()
        print(f"[PING] 4️⃣ Processing platform '{platform_proper}' incremental append...")

        # Find last processed ID for this platform
        last_id = 0
        if not create_new:
            with engine.connect() as conn:
                last_id = conn.execute(
                    text(f"SELECT MAX(PDPSearchId) FROM {SCHEMA}.{TGT_TABLE} WHERE LOWER(Platform) = :platform"),
                    {"platform": platform_proper.lower()}
                ).scalar() or 0
        print(f"  [PING] Last PDPSearchId for platform '{platform_proper}': {last_id}")

        # Filter new rows for this platform
        platform_df = transformed_df[
            (transformed_df["Platform"].str.lower() == platform_proper.lower()) &
            (pd.to_numeric(transformed_df["PDPSearchId"], errors="coerce") > last_id)
        ]
        print(f"  [PING] New rows to append for '{platform_proper}': {len(platform_df)}")
        if platform_df.empty:
            print(f"  [PING] No new data for platform '{platform_proper}'. Skipping.")
            continue

        # Append in chunks for large data
        for start in range(0, len(platform_df), chunk_size):
            chunk = platform_df.iloc[start:start+chunk_size]
            print(f"    [PING] Appending rows {start + 1}-{start + len(chunk)}")
            with engine.begin() as conn:
                chunk.to_sql(
                    TGT_TABLE,
                    conn,
                    schema=SCHEMA,
                    if_exists="replace" if create_new and not first_write_done else "append",
                    index=False,
                    dtype=dtype_map,
                    method='multi',
                    chunksize=chunk_size,
                )
            first_write_done = True
            total_rows_appended += len(chunk)
        print(f"  [PING] Finished appending for '{platform_proper}'")

    print(f"[ALL DONE] Total rows appended across platforms: {total_rows_appended}")

if __name__ == "__main__":
    run_etl()
