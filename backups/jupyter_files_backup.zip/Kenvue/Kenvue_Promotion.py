import gspread
from gspread_dataframe import get_as_dataframe
from oauth2client.service_account import ServiceAccountCredentials
from gspread_dataframe import set_with_dataframe
import pyodbc
import pandas as pd
from datetime import datetime
import numpy as np

# Setup
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("python-459011-73acbdff4227.json", scope)
client = gspread.authorize(creds)

# Python Master for ISPStore
sheet = client.open_by_key("1ELTy7cpgwV2A57nv3URES0yHltXofTyr9XxxDUhH2KA") # Master Sheets ( Dimensions Sheet)

ISPMaster = sheet.worksheet("ISPMaster")
StoreMaster = sheet.worksheet("StoreMaster")
PromoTarget = sheet.worksheet("PromoTarget")
PositionMaster = sheet.worksheet("PositionMaster")
ExceptionCases = sheet.worksheet("ExceptionCases")

ISPMaster = get_as_dataframe(ISPMaster)
StoreMaster = get_as_dataframe(StoreMaster)
PromoTarget = get_as_dataframe(PromoTarget)
PositionMaster = get_as_dataframe(PositionMaster)
ExceptionCases = get_as_dataframe(ExceptionCases)

server = '157.119.230.120,4071'    
database = 'PowerBI_LISV2'      
username = 'sa'
password = 'Y0m@Sql.!.123'

# Connection string
conn_str = f"""
    DRIVER={{ODBC Driver 17 for SQL Server}};
    SERVER={server};
    DATABASE={database};
    UID={username};
    PWD={password};
    TrustServerCertificate=yes;
"""

query = """
WITH S AS (
    SELECT *,
           TRY_CONVERT(date, [SubmittedDate&Time], 105) AS SubmittedDate
    FROM [PowerBI_LISV2].[JohnsonJohnsonManagement].[PromotionTrackingReportExport]
    WHERE Month = 8
      AND Year = 2025
      -- AND VisitId = '391022' 
	  and  lower(UserName) not like '%test%' and lower(LISStoreCode) NOT LIKE '%test%' and Designation != 'Supervisor'
)
SELECT *
FROM S
WHERE SubmittedDate BETWEEN '2025-08-01' AND '2025-08-07';

"""
print("......in progress")

conn = pyodbc.connect(conn_str)
df = pd.read_sql(query, conn)

df1 = df[['VisitId', 'SubmittedDate',
        'Region', 'State', 'City',
       'Username', 'FullName',
       'LISStoreCode', 'StoreName', 'Format', 'ProductCode', 'ProductName',
       'Offer', 'IsSamePromotionRunning', 'SameonPOS', 'SameonShelftalker',
       'CountOfFacing', 'Reason', 'PromotionType', 'PromotionComment',
       'PhotoLink',
       'StockCount']]

StoreMaster1 = StoreMaster[['JNJ Store Codes','Supervisor','ABI Name','RKAM Name','Store Code','Chain Name','Flag']]
df1_StoreMaster = pd.merge(df1,StoreMaster1,left_on ='LISStoreCode',right_on='Store Code',how = 'inner')

# df1_StoreMaster[:10].to_csv(r'C:\Users\Administrator\LIS\Kenvue\test.csv', index=False)

PromoTarget1 =  PromoTarget[['Account','PromoCode']]
df1_StoreMaster_Promo = pd.merge(df1_StoreMaster,PromoTarget1, how = 'inner',left_on=['ProductCode', 'Chain Name'], right_on=['PromoCode', 'Account'])

df1_StoreMaster_Promo['SubmittedDate'] = pd.to_datetime(df1_StoreMaster_Promo['SubmittedDate'], errors='coerce')
# Convert 'dol' to datetime, treating '-' as NaT
ISPMaster['DOL_CLEAN'] = pd.to_datetime(ISPMaster['DOL'].replace('-', pd.NaT), errors='coerce')

df1_StoreMaster_Promo = pd.merge(df1_StoreMaster_Promo,ISPMaster[['ISP_MR_Code','DOL_CLEAN']], left_on='Username',right_on='ISP_MR_Code', how='left')


# Create the flag column for dol data logic
df1_StoreMaster_Promo['dol_flag'] = np.where(
    df1_StoreMaster_Promo['DOL_CLEAN'].isna(), 1,
    np.where(df1_StoreMaster_Promo['SubmittedDate'] > df1_StoreMaster_Promo['DOL_CLEAN'], 0, 1)
)

final_df =df1_StoreMaster_Promo[df1_StoreMaster_Promo['dol_flag']==1]

final_df = final_df.drop_duplicates(subset=['SubmittedDate', 'Username', 'LISStoreCode', 'ProductName'])

final_df2 = pd.merge(final_df,PositionMaster, how = 'left', left_on = ['LISStoreCode','Username'],right_on = ['Store Code','ISP/MR'])

final_df2['PositionRank'] = (
    final_df2.groupby(['LISStoreCode','SubmittedDate', 'ProductName'])['Position']
    .rank(method='dense')  # or 'min', 'first', 'max' based on need
)

final_df2['Region'] = final_df2['Region'].apply(lambda x: 'North & East' if x in ['North', 'East'] else x)
# final_df2['PhotoLink'] = final_df2['PhotoLink'].apply(lambda x: f'=HYPERLINK("{x}", "View Photo")')

final_df2 = final_df2[final_df2['PositionRank']==1]

final_df2 = final_df2.drop(['Store Code_x', 'Flag', 'Account','PromoCode','ISP_MR_Code','DOL_CLEAN','dol_flag','Store Code_y','ISP/MR','Position','PositionRank'], axis=1)
final_raw=final_df2[['VisitId','SubmittedDate','Region','State','City','JNJ Store Codes','LISStoreCode','StoreName','Chain Name','Format','Username','FullName','Supervisor','ABI Name','RKAM Name','ProductCode','ProductName','Offer','IsSamePromotionRunning','SameonPOS','SameonShelftalker','CountOfFacing','Reason','PromotionType','PromotionComment','PhotoLink','StockCount']]

final_raw.to_csv(r'C:\Users\Administrator\LIS\Kenvue\jnj_promoiton_final_raw.csv', index=False)

promotion_avail_dtlevel=final_raw.drop(['Offer','SameonPOS','SameonShelftalker','CountOfFacing','Reason','PromotionType','PromotionComment','PhotoLink','StockCount'], axis =1 )

promotion_avail_dtlevel['ProductHeader'] = promotion_avail_dtlevel['ProductCode'] + ' (' + promotion_avail_dtlevel['ProductName'] + ')'

promotion_avail_dtlevel_pivot = promotion_avail_dtlevel.pivot_table(
    index=['VisitId','SubmittedDate','Region','State','City','JNJ Store Codes','LISStoreCode','StoreName','Chain Name','Format','Username','FullName','Supervisor','ABI Name','RKAM Name'], 
    columns='ProductHeader',
    values='IsSamePromotionRunning',
    aggfunc='first'
).reset_index()

promotion_avail_dtlevel_pivot = promotion_avail_dtlevel_pivot.fillna('-')

print("......in progress")

id_vars = ['VisitId','SubmittedDate','Region','State','City','JNJ Store Codes','LISStoreCode','StoreName','Chain Name','Format','Username','FullName','Supervisor','ABI Name','RKAM Name']  # Add others if needed

# Melt the DataFrame
promotion_avail_dtlevel_reupivot = promotion_avail_dtlevel_pivot.melt(
    id_vars=id_vars,
    var_name='ProductHeader',
    value_name='Status'
)

promotion_avail_dtlevel_reupivot['ProductCode'] = promotion_avail_dtlevel_reupivot['ProductHeader'].str.extract(r'^(.*?)\s*\(')

promotion_avail_dtlevel_reupivot['key'] = promotion_avail_dtlevel_reupivot['Chain Name'] + promotion_avail_dtlevel_reupivot['ProductCode']
PromoTarget['key'] = PromoTarget['Account'] + PromoTarget['PromoCode']
valid_keys = set(PromoTarget['key'])

promotion_avail_dtlevel_reupivot['revised_status'] = promotion_avail_dtlevel_reupivot.apply(
    lambda row: 'No' if row['Status'] == '-' and row['key'] in valid_keys else row['Status'],
    axis=1
)

promotion_avail_dtlevel_reupivot.drop(columns='key', inplace=True)
PromoTarget.drop(columns='key', inplace=True)

promotion_avail_dtlevel_reupivotX = promotion_avail_dtlevel_reupivot[(promotion_avail_dtlevel_reupivot['Status']=='-') & (promotion_avail_dtlevel_reupivot['revised_status']=='No')]

ExceptionCases['SubmittedDate'] = pd.to_datetime(ExceptionCases['SubmittedDate'].astype(str),dayfirst=True).dt.date
promotion_avail_dtlevel_reupivot['SubmittedDate'] = pd.to_datetime(promotion_avail_dtlevel_reupivot['SubmittedDate']).dt.date

ExceptionCases['LISStoreCode'] = ExceptionCases['LISStoreCode'].str.strip().str.upper()
promotion_avail_dtlevel_reupivot['LISStoreCode'] = promotion_avail_dtlevel_reupivot['LISStoreCode'].str.strip().str.upper()


promotion_avail_dtlevel_reupivot = promotion_avail_dtlevel_reupivot.merge(
    ExceptionCases,
    how='left',
    on=['SubmittedDate', 'LISStoreCode', 'ProductCode'],
    indicator='merge_flag'
)

print("......in progress")

promotion_avail_dtlevel_reupivot['is_exception_flag'] = (promotion_avail_dtlevel_reupivot['merge_flag'] == 'both').astype(int)
promotion_avail_dtlevel_reupivot.drop(columns='merge_flag', inplace=True)

# Validation Code to chek the Correct ExceptionCases Mappoing

exceptions_df = promotion_avail_dtlevel_reupivot[promotion_avail_dtlevel_reupivot['is_exception_flag'] == 1]
columns_to_export = ExceptionCases.columns
export_df = exceptions_df[list(columns_to_export)]

# sheet = client.open("1ELTy7cpgwV2A57nv3URES0yHltXofTyr9XxxDUhH2KA").worksheet("Exception Cases")
Data = sheet.worksheet("ExceptionCases")
# Get starting cell coordinates
start_row = 2
start_col = 8  # Column H is 8th

# Clear a block if needed (optional)
Data.batch_clear(['H2:K1000'])

# Export DataFrame to Google Sheet starting at H2
set_with_dataframe(Data, export_df, row=start_row, col=start_col, include_column_header=True)


# creating re pivot
df_repivot = promotion_avail_dtlevel_reupivot.drop(columns=['ProductCode', 'Status'])

# Pivot the data at 'ProductHeader'
df_pivoted_raw = df_repivot.pivot_table(
    index=['VisitId','SubmittedDate', 'Region', 'State', 'City', 'JNJ Store Codes', 'LISStoreCode', 
           'StoreName', 'Chain Name', 'Format', 'Username', 'FullName', 
           'Supervisor', 'ABI Name', 'RKAM Name'],
    columns='ProductHeader',
    values='revised_status',
    aggfunc='first'  # or use ' '.join if you expect multiple values and want to merge
)
df_pivoted_raw.reset_index(inplace=True)

print("......in progress")
# Creating Target Achievment Matrix ( doing all the Exception Adjutments)
filtered_df_repivot = df_repivot[(df_repivot['revised_status'] != '-') & (df_repivot['is_exception_flag'] == 0)]

agg_filtered_df_repivot = filtered_df_repivot.groupby([
    'VisitId'
]).agg(
    valid_promo_count=('revised_status', 'count'),
    #valid_promo_count = ('revised_status', lambda x: (x != '-').sum()),
    yes_promo_count   = ('revised_status', lambda x: (x == 'Yes').sum())
).reset_index()
agg_filtered_df_repivot2 = pd.merge(df_pivoted_raw,agg_filtered_df_repivot, how='left', on = 'VisitId')

agg_filtered_df_repivot2.to_csv(r'C:\Users\Administrator\LIS\Kenvue\jnj_promotion_avail_dtlevel_pivot.csv', index=False)

print("......code completed")

#------------------------------------------


from datetime import datetime, timedelta
import smtplib
from email.message import EmailMessage
import os
import mimetypes

sender_email   = "reports.mis@loveinstore.com"
app_password   = "ydfd ntvg qcfp xxbi"
recipients     = [
    "kunalk@loveinstore.com","amitr@loveinstore.com,atulk@loveinstore.com,rukbeers@loveinstore.com"
]
subject_tpl    = "Kenvue Promotion Data Date Level till {date}"
body_template  = """
Dear All,

Kenvue Promotion Data Date Level till {date}

<Important>

Team Please check the Backend ,Mappiing File , In case of any change in mapping , please raise a request to re run the python code
<strong>Backend File</strong>
https://docs.google.com/spreadsheets/d/1ELTy7cpgwV2A57nv3URES0yHltXofTyr9XxxDUhH2KA/edit?gid=0#gid=0

Regards,
Team Love In Store
"""


# Define the file path
file_path = r"C:\Users\Administrator\LIS\Kenvue\jnj_promotion_avail_dtlevel_pivot.csv"  # Replace with your actual file path

now = datetime.now() - timedelta(days=1)
rounded = now.replace(minute=0, second=0, microsecond=0)
time_str = rounded.strftime("%I:%M %p")
formatted_date = now.strftime("%d-%b-%Y")

msg = EmailMessage()
msg["From"]    = sender_email
msg["To"]      = ", ".join(recipients)
msg["Subject"] = subject_tpl.format(date=formatted_date, time=time_str)
msg.set_content(body_template.format(date=formatted_date, time=time_str))

# ➕ Attach CSV file
try:
    with open(file_path, "rb") as f:
        file_data = f.read()
        maintype, subtype = mimetypes.guess_type(file_path)[0].split("/")
        msg.add_attachment(file_data, maintype=maintype, subtype=subtype, filename=os.path.basename(file_path))
except Exception as e:
    print("❌ Failed to attach file:", e)

# ✉️ Send the email
try:
    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)
    print("✅ Email sent successfully to:", ", ".join(recipients))

    # Optional: remove the file after sending
    os.remove(file_path)
    print("✅ Deleted temporary file:", file_path)

except Exception as e:
    print("❌ Failed to send email:", e)


print("done- mail sent")




























