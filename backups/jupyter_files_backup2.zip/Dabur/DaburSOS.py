import pandas as pd
import pyodbc 
from openpyxl import load_workbook
from datetime import datetime

server = '157.119.230.120,4071'    
database = 'PowerBI_LISV2'      
username = 'sa'
password = 'Y0m@Sql.!.123'

# Connection string
conn_str = f"""
    DRIVER={{ODBC Driver 17 for SQL Server}};
    SERVER={server};
    DATABASE={database};
    UID={username};
    PWD={password};
    TrustServerCertificate=yes;
"""

SOSQuerry =""" SELECT
       [VisitId]
      ,FORMAT(TRY_CONVERT(date, [SubmittedDate&Time], 105), 'dd-MM-yyyy') as 'SubmittedDate&Time'
      ,[SyncDate&Time]
      ,[Month]
      ,[Year]
      ,[Region]
      ,[State]
      ,[City]
      ,[RSMCode]
      ,[BranchCode]
      ,[ASMCode]
      ,[SOCode]
      ,[SupervisorCode]
      ,[ISPCode]
      ,[UserName]
      ,[FullName]
      ,[Designation]
      ,[ClientStoreCode]
      ,[LISStoreCode]
      ,[StoreName]
      ,[StoreAddress]
      ,[Format]
      ,[ChainCode]
      ,[ChainName]
      ,[SubChainName]
      ,[StoreType]
      ,[StoreClub]
      ,[Distributorcode]
      ,[DistributorName]
      ,[PJPStatus]
      ,[IscategoryAvailable]
      ,[ReasonforNonavailability]
      ,[AuditStatus]
      ,[CategoryTrackingName]
      ,[ISPCategoryTrackingProductCode]
      ,[CategoryProductName]
      ,[StackCount]
      ,[DepthCount]
      ,[ShelfCount]
      ,[Facings]
      ,[TotalFacings]
      ,[FacingContribution]
      ,[TgtCatSOS]
      ,[SOSAch]
      ,[Score]
      ,[AppQuestions]
      ,[AppResponse]
      ,[PortalQuestions]
      ,[PortalResponse]
      ,[PortalResponsePoints]
      ,[Latitude]
      ,[Longitude]
      ,[ImageLink]
  FROM [PowerBI_LISV2].[DaburPharmaManagement].[CategoryTrackingVisitExport]
  where MONTH = 08 and [UserName] not like '%ISPStar%'and  [Username] not like '%SUP%' and LOWER([Username]) not like '%test%';

"""

conn = pyodbc.connect(conn_str)
SOSData = pd.read_sql(SOSQuerry, conn)



SOSData.to_csv(r'C:\Users\Administrator\LIS\Dabur\DaburSOSData.csv', index=False)


csv_files = [r'C:\Users\Administrator\LIS\Dabur\DaburSOSData.csv']

# emailer

from datetime import datetime, timedelta
import smtplib
from email.message import EmailMessage
import mimetypes
import os
import zipfile


sender_email   = "reports.mis@loveinstore.com"
app_password   = "ydfd ntvg qcfp xxbi"
# recipients     = ["kunalk@loveinstore.com","anandk@loveinstore.com","pankajs@loveinstore.com"]

# ,"anandk@loveinstore.com"

# "kunalk@loveinstore.com","anandk@loveinstore.com",'pankajs@loveinstore.com']

subject_tpl    = "Dabur SOS CSV Dump - {date} {time}"
body_template  = """
Please find attached Data for {date} at {time}

Regards,
Team Love In Store
"""
now = datetime.now() - timedelta(days=1)
rounded = now.replace(minute=0, second=0, microsecond=0)
time_str = rounded.strftime("%I:%M %p")
formatted_date = now.strftime("%d-%b-%Y")

# Create a ZIP archive
zip_file = r"C:\Users\Administrator\LIS\Dabur\Reports_{date}.zip".format(date=formatted_date.replace("-", ""))
with zipfile.ZipFile(zip_file, "w", zipfile.ZIP_DEFLATED) as zipf:
    for file_path in csv_files:
        zipf.write(file_path, os.path.basename(file_path))  # save only filename in ZIP

# Create email
msg = EmailMessage()
msg["From"]    = sender_email
msg["To"]      = ", ".join(recipients)
msg["Subject"] = subject_tpl.format(date=formatted_date, time=time_str)
msg.set_content(body_template.format(date=formatted_date, time=time_str))

# Attach ZIP
with open(zip_file, "rb") as f:
    file_data = f.read()
msg.add_attachment(file_data, maintype="application", subtype="zip", filename=os.path.basename(zip_file))

# Send email
with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
    smtp.login(sender_email, app_password)
    smtp.send_message(msg)

print(f"✅ Email sent with compressed attachment: {os.path.basename(zip_file)}")

# Loop through files
with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
    smtp.login(sender_email, app_password)

    for file_path in csv_files:
        file_name = os.path.basename(file_path)

        # Build email
        msg = EmailMessage()
        msg["From"]    = sender_email
        msg["To"]      = ", ".join(recipients)
        msg["Subject"] = subject_tpl.format(file=file_name, date=formatted_date, time=time_str)
        msg.set_content(body_template.format(file=file_name, date=formatted_date, time=time_str))

        # Attach CSV
        with open(file_path, "rb") as f:
            file_data = f.read()
        msg.add_attachment(file_data, maintype="text", subtype="csv", filename=file_name)

        # Send email
        smtp.send_message(msg)
        print(f"✅ Sent email with {file_name}")
