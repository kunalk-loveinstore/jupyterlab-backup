# ----------------------------------
# Import Libraries
# ----------------------------------
import gspread
from gspread_dataframe import get_as_dataframe, set_with_dataframe
from oauth2client.service_account import ServiceAccountCredentials
import pyodbc
import pandas as pd
import numpy as np
from datetime import timedelta

# ----------------------------------
# 1. Google Sheets Authentication
# ----------------------------------
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("python-459011-73acbdff4227.json", scope)
client = gspread.authorize(creds)

# ----------------------------------
# 2. Open Google Sheets Worksheets
# ----------------------------------
sheet = client.open_by_key("14wMJ8iak6tInUhO9Qbg8d73WWouW-L0pbf9KY_fRXBY")
Supervisor_Att_Master= sheet.worksheet("Supervisor Att")
Attendence_sh = sheet.worksheet("Attendence Pivot")

# Convert to DataFrame
Supervisor_Att_Master = get_as_dataframe(Supervisor_Att_Master)
Supervisor_Att_Master = Supervisor_Att_Master.dropna(how='all')

# ----------------------------------
# 4. SQL Connection and Attendance Fetch
# ----------------------------------
server = '157.119.230.120,4071'
database = 'PowerBI_LISV2'
username = 'sa'
password = 'Y0m@Sql.!.123'

conn_str = f"""
    DRIVER={{ODBC Driver 17 for SQL Server}};
    SERVER={server};
    DATABASE={database};
    UID={username};
    PWD={password};
    TrustServerCertificate=yes;
"""

try:
    conn = pyodbc.connect(conn_str)
    print("✅ Connected to SQL Server")

    query = '''
        SELECT  [UserName] AS [Sup Code],
                CONVERT(DATE, [DATE]) AS Date,
                CASE 
                  WHEN [Status] = 'Leave' THEN 'L'
                  WHEN [Status] IN ('Holiday','National Holiday') THEN 'H'
                  WHEN [Status] IN ('WeekOff', 'Week Off') THEN 'WO'
                  WHEN [Status] = 'Comp Off' THEN 'CO'
                  WHEN [Status] = 'Present' THEN 'P'
                  WHEN [Status] = 'Absent' THEN 'A'
                  WHEN [Status] = 'Meeting' THEN 'M'
                  ELSE [Status] 
               END AS [Status]
               FROM [PowerBI_LISV2].[AmulManagement].[ISPAttendanceMasterExport]
               WHERE [Month] = MONTH(GETDATE() - 1)
                 AND [Year] = YEAR(GETDATE() - 1)
                 AND UserName LIKE '%Sup%'
    '''

    Attendence_df = pd.read_sql(query, conn)
    conn.close()

except Exception as e:
    print(f"❌ SQL Error: {e}")
    Attendence_df = pd.DataFrame()
    
    


# Step 1: Identify static employee fields
index_cols = [col for col in Attendence_df.columns if col not in ['Date', 'Status']]

# Step 2: Pivot for date-wise status
pivot_df = Attendence_df.pivot_table(
    index=index_cols,
    columns='Date',
    values='Status',
    aggfunc='first'
).reset_index()

# Step 3: Arrange columns properly
pivot_df.columns.name = None
pivot_df = pivot_df.reindex(columns=index_cols + sorted([col for col in pivot_df.columns if col not in index_cols]))


data= pd.merge(Supervisor_Att_Master,pivot_df,how='left',on='Sup Code')


# Upload Pivoted Data
Attendence_sh.batch_clear(["A:AX"])
set_with_dataframe(Attendence_sh, data)