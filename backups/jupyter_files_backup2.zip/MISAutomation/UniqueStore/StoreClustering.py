import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist

df = pd.read_csv('clustering_model_input.csv')

# Convert lat-long to NumPy array
coords = df[['MedianLatitude', 'MedianLongitude']].to_numpy()

# Standardize coordinates
scaler = StandardScaler()
coords_scaled = scaler.fit_transform(coords)

db = DBSCAN(eps=0.0005, min_samples=5, metric='haversine').fit(coords_scaled)

df['cluster_id'] = db.labels_

df.to_csv('storeclutering_model_output.csv')